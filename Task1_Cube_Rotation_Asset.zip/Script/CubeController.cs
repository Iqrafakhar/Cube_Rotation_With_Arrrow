using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour
{
    //initialize the reference for the scal or size changing
    Vector3 size;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       // transform.localScale = new Vector3(scaleX,scaleY,scaleZ);
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.Rotate(45, 0, 0);
        }

        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.Rotate(0, 45, 0);
        }

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            transform.Rotate(0, 0, 45);
        }

        if(Input.GetKeyDown(KeyCode.DownArrow))
        {
            transform.Rotate(29,30,10);
        }

        if(Input.GetKeyDown(KeyCode.Space))
        {
            size = transform.localScale;
            size.x += 0.2f;
            size.y += 0.2f;
            size.z += 0.2f;
            transform.localScale = size;
	}
            if(Input.GetKeyUp(KeyCode.Space))
           {
                size = transform.localScale;
                size.x = 1.0f;
                size.y = 1.0f;
                size.z = 1.0f;
                transform.localScale = size;
               
            }
        
    }
}
